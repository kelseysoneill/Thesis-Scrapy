import scrapy
from scrapy.linkextractors import LinkExtractor
from scrapy.spiders import CrawlSpider, Rule
from CNNTest.items import MyItem  # item class 
from scrapy.linkextractors import LinkExtractor
from scrapy.selector import Selector

class MySpider(CrawlSpider):
    name = "CNN_content"  # unique identifier for the spider
    allowed_domains = ['cnn.com']  # limits the crawl to this domain list
    start_urls = [
    'http://www.cnn.com/2015/10/09/politics/john-kasich-super-pac-marco-rubio/index.html',
    'http://www.cnn.com/2015/10/05/politics/donald-trump-marco-rubio-care-package/',
    'http://www.cnn.com/2015/10/02/politics/ted-cruz-club-for-growth-conference/index.html',
    'http://www.cnn.com/2015/09/01/politics/2016-donald-trump-hispanic-chamber-of-commerce/index.html'
    
    ]  # first url to crawl in domain

    def parse(self, response):
        sel = Selector(response)
        results = []
        item = MyItem()
        item['article_title'] = sel.xpath('.//h1[@class="pg-headline"]/text()').extract()
        item['article_author1'] = sel.xpath('.//p[@class="metadata__byline"]/span/text()').extract()
        item['article_author2'] = sel.xpath('.//p[@class="metadata__byline"]/span/a/text()').extract()
        item['article_content'] = sel.xpath('.//div[@class="zn-body__read-all"]/p/text()').extract()
        item['article_timestamp'] = sel.xpath('.//p[@class="update-time"]/text()').extract()
        results.append(item)
        return results

